
async function loadDataFromApi() {
    try {
        const response = await axios.get('https://65b4864e41db5efd28669b3d.mockapi.io/Malta');
        const data = response.data[0];
        document.getElementById('continuousDmg').innerText = `Continuous Damage: ${data.continuous_dmg}`;
        document.getElementById('shellExpDmg').innerText = `Damage by Shell Explosions: ${data.shell_exp_dmg}`;
        document.getElementById('prioritySector').innerText = `Priority Sector Reinforcement: ${data.priority_sector}%`;
        document.getElementById('maxSpeed').innerText = `Maximum Speed: ${data.max_speed} knots`;
        document.getElementById('turnRadius').innerText = `Turning Circle Radius: ${data.turn_radius} m`;
        document.getElementById('rudderTime').innerText = `Rudder Shift Time: ${data.rudder_time} s`;
        document.getElementById('hitpoints').innerText = `Hit Points: ${data.hitpoints}`;
        document.getElementById('torp_dmg_red').innerText = `Torpedo Protection. Damage Reduciton: ${data.torp_dmg_red}%`;
        document.getElementById('aa_malta').innerText = `Attack Aircraft: ${data.aa_malta}`;
        document.getElementById('tb_malta').innerText = `Torpedo Bombers Aircraft: ${data.tb_malta}`;
        document.getElementById('b_malta').innerText = `Bombers Aircraft: ${data.b_malta}`;
        document.getElementById('artillery').innerText = `Secondary Battery: ${data.artillery}`;
    } catch (error) {
        console.error('Ошибка при загрузке данных из API', error);
    }
}

loadDataFromApi();
