let animateBtn = document.getElementById('animate-btn');
animateBtn.onclick = function () {
    let position = 0;
    let fox = document.getElementById('animate-fox');
    let interval = setInterval(animation, 5);

    function animation () {
        if (position == 400){
            clearInterval(interval);
        } else {
            position++;
            fox.style.left = position + "px";
        }
    }
}